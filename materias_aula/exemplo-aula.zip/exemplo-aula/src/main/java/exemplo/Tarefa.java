package exemplo;

public class Tarefa {

    private String descricao;
    
    private Boolean importante;

    public Tarefa(String descricao, Boolean importante) {
        this.descricao = descricao;
        this.importante = importante;
    }

        
    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public Boolean getImportante() {
        return importante;
    }

    public void setImportante(Boolean importante) {
        this.importante = importante;
    }

    @Override
    public String toString() {
        return "Tarefa{" + "descricao=" + descricao + ", importante=" + importante + '}';
    }
    
    
}
