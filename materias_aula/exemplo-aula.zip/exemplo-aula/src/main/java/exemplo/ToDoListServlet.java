package exemplo;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "todo", urlPatterns = {"/todo"})
public class ToDoListServlet extends HttpServlet {

    private List<Tarefa> tarefas = new ArrayList<>();
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
                
        resp.setContentType("text/html;charset=UTF-8");
        try(PrintWriter out = resp.getWriter()){
            out.println(geraHtml());
        }        
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) 
            throws ServletException, IOException {
        
     
        String descricao = req.getParameter("descricao");
        boolean importante = "on".equalsIgnoreCase(req.getParameter("importante"));
        
        tarefas.add(new Tarefa(descricao, importante));
        
        
        resp.setContentType("text/html;charset=UTF-8");
        try(PrintWriter out = resp.getWriter()){
            out.println(geraHtml());
        }     
        
    }
    
    private String geraHtml() {
        String tarefasHtml = "";
        
        for(Tarefa tarefa : tarefas) {
            if (tarefa.getImportante()){
                tarefasHtml += "<li><strong>"+tarefa.getDescricao()+"</strong></li>";
            } else {
                tarefasHtml += "<li>"+tarefa.getDescricao()+"</li>";
            }
            
        }
       
        return "<!DOCTYPE html>\n" +
                    "<html>\n" +
                    "    <head>\n" +
                    "        <title>TO DO Dinâmico</title>\n" +
                    "        <meta http-equiv=\"Content-Type\" content=\"text/html; charset=UTF-8\">\n" +
                    "        <style type=\"text/css\">\n" +
                    "            .centro {\n" +
                    "                margin: 0 auto;\n" +
                    "                width: 480px;\n" +
                    "            }\n" +
                    "        </style>\n" +
                    "    </head>\n" +
                    "    <body>\n" +
                    "        <div class=\"centro\">\n" +
                    "               <h1>TO DO Dinâmico</h1>\n" +
                    "               <h2>Lista de tarefas web dinâmica </h2>\n" +
                    "               <p>Insira suas tarefas na lista abaixo e controle o que precisa fazer.</p>\n" +
                    "               <ul>\n" +
                    tarefasHtml +
                    "               </ul> \n" +
                    "               <hr />\n" +
                    "               <form action=\"#\" method=\"post\">\n" +
                    "                   <input type=\"text\" name=\"descricao\" placeholder=\"Insira nova tarefa\" />\n" +
                    "                   <input type=\"checkbox\" name=\"importante\" /> Importante\n" +
                    "                   <input type=\"submit\" name=\"enviar\" value=\"Enviar\" /> \n" +
                    "               </form>\n" +
                    "        </div>\n" +
                    "        \n" +
                    "    </body>\n" +
                    "</html>";
    }
    

    
    
    
}
