package controllers;

import java.io.IOException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Avaliacao;
import model.Resposta;

@WebServlet("/salvar")
public class SalvarAvaliacaoController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, 
            HttpServletResponse resp) throws ServletException, 
                                             IOException {
            
        Integer q1 = Integer.parseInt(req.getParameter("q1"));
        Integer q2 = Integer.parseInt(req.getParameter("q2"));
            
        HttpSession session = req.getSession(true);
        Avaliacao avaliacao = (Avaliacao)session
                                    .getAttribute("avaliacao");
        
        if (avaliacao == null) {
            avaliacao = new Avaliacao();
            session.setAttribute("avaliacao", avaliacao);
        }
        
        Resposta resposta = new Resposta();
        resposta.setQuestao1(q1);
        resposta.setQuestao2(q2);
        
        avaliacao.getRespostas().add(resposta);
        
        RequestDispatcher rd = req.getRequestDispatcher("/resultado.jsp");
        rd.forward(req, resp);
    }

}
