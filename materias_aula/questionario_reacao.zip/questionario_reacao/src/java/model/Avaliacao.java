package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Avaliacao {
    
    private List<Resposta> respostas = new ArrayList<>();

    public List<Resposta> getRespostas() {
        return respostas;
    }

    public void setRespostas(List<Resposta> respostas) {
        this.respostas = respostas;
    }
    
    public double[] getPercentualRespostasQuestao1() {
         
        double[] percentuais = new double[5];
        for (Resposta r : respostas) {
            percentuais[r.getQuestao1()-1] += 1.0/respostas.size();
        }
        return percentuais;
    }
    

    @Override
    public String toString() {
        return "Avaliacao{" + "respostas=" + respostas + '}';
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 79 * hash + Objects.hashCode(this.respostas);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Avaliacao other = (Avaliacao) obj;
        if (!Objects.equals(this.respostas, other.respostas)) {
            return false;
        }
        return true;
    }
    
    
}
