package model;

import java.util.Objects;

public class Resposta {
    
    private Integer questao1;
    
    private Integer questao2;

    public Integer getQuestao1() {
        return questao1;
    }

    public void setQuestao1(Integer questao1) {
        this.questao1 = questao1;
    }

    public Integer getQuestao2() {
        return questao2;
    }

    public void setQuestao2(Integer questao2) {
        this.questao2 = questao2;
    }

    @Override
    public String toString() {
        return "Resposta{" + "questao1=" + questao1 + ", questao2=" + questao2 + '}';
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 83 * hash + Objects.hashCode(this.questao1);
        hash = 83 * hash + Objects.hashCode(this.questao2);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final Resposta other = (Resposta) obj;
        if (!Objects.equals(this.questao1, other.questao1)) {
            return false;
        }
        if (!Objects.equals(this.questao2, other.questao2)) {
            return false;
        }
        return true;
    }
    
    
}
